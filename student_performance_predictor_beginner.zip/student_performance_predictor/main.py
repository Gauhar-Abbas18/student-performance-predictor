"""Beginner-friendly Student Performance Predictor.
The included data is fictional and for learning only.
"""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error


def main():
    # Read the sample data from the CSV file.
    data = pd.read_csv("student_data.csv")

    # Inputs: study hours and attendance. Target: exam score.
    X = data[["study_hours", "attendance"]]
    y = data["exam_score"]

    # Keep a few rows aside to test the model.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    # Train a simple Linear Regression model.
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Check average prediction error on the test rows.
    test_predictions = model.predict(X_test)
    error = mean_absolute_error(y_test, test_predictions)

    print("=" * 42)
    print("   STUDENT PERFORMANCE PREDICTOR")
    print("=" * 42)
    print(f"Rows in sample dataset: {len(data)}")
    print(f"Mean absolute error on test rows: {error:.1f} marks")
    print("Small fictional dataset: results may not generalize.\n")

    try:
        hours = float(input("Study hours per day (0 to 12): "))
        attendance = float(input("Attendance percentage (0 to 100): "))

        if not 0 <= hours <= 12:
            print("Please enter study hours from 0 to 12.")
            return
        if not 0 <= attendance <= 100:
            print("Please enter attendance from 0 to 100.")
            return

        student = pd.DataFrame(
            [[hours, attendance]],
            columns=["study_hours", "attendance"]
        )
        score = model.predict(student)[0]
        score = max(0, min(100, score))

        print(f"\nEstimated exam score: {score:.1f}/100")
        print("This is an estimate, not a guarantee.")
    except ValueError:
        print("Please enter numbers only.")

    # Save a simple graph of the sample data.
    plt.scatter(data["study_hours"], data["exam_score"])
    plt.xlabel("Study hours per day")
    plt.ylabel("Exam score")
    plt.title("Sample Data: Study Hours and Exam Scores")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("study_hours_vs_scores.png")
    print("\nGraph saved as study_hours_vs_scores.png")


if __name__ == "__main__":
    main()
