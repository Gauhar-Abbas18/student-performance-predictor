# Student Performance Predictor

A beginner-level Python project that estimates an exam score from study hours and attendance using Linear Regression.

## Why I made it
I wanted to practice Python, work with a CSV dataset, and try a basic machine-learning model. I kept it small so I could understand each step.

## Features
- Reads `student_data.csv`
- Trains a Linear Regression model
- Tests it on a small held-out sample
- Prints Mean Absolute Error (MAE)
- Takes study hours and attendance as input
- Predicts an estimated score
- Saves a scatter plot

## Run it
1. Install Python 3.
2. Open a terminal in this folder.
3. Install libraries: `pip install -r requirements.txt`
4. Run: `python main.py`
5. Enter study hours and attendance when prompted.

## Example
Study hours: `4`
Attendance: `75`

## What I learned
- Reading CSV files with pandas
- Separating features (`X`) and target (`y`)
- Splitting data into training and testing sets
- Training Linear Regression
- Checking error with MAE
- Validating user input
- Creating a graph with matplotlib

## Limitations
The dataset is fictional and very small, for practice only. Study hours and attendance do not fully explain academic performance. This model can be inaccurate and should not be used to grade, rank, or make decisions about real students.
